#!/usr/bin/env python3
import sys, os, json, re, urllib.request, random, time, xml.etree.ElementTree as ET, datetime
import vlc, psutil, socketio, threading, requests
from urllib.parse import quote
from PyQt6 import QtWidgets, QtCore, QtGui
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QLineEdit, QLabel, QListWidget, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QSplitter, QSlider, QTextEdit, QFormLayout, QComboBox, QFrame, QMenu, QStatusBar, QProgressBar
)
from PyQt6.QtGui import QIcon, QPixmap

###################################
# Global Settings and Folders
###################################
EPG_URL = "http://1ere-serrvices.com:80/xmltv.php?username=363ys5p123e&password=perv0j5t8x&type=m3u_plus&output=mpegts"
PLAYLIST_FOLDER = os.path.join(os.getcwd(), "playlists")
PRIVATE_PLAYLIST_FOLDER = os.path.join(os.getcwd(), "private_playlists")
RECORDINGS_FOLDER = os.path.join(os.getcwd(), "recordings")
CHANNEL_IMAGES_FOLDER = os.path.join(os.getcwd(), "data", "channel_images")
BACKGROUND_IMAGES_FOLDER = os.path.join(os.getcwd(), "data", "background_images")
CONFIG_FILE = os.path.join(os.getcwd(), "config.json")
for folder in [PLAYLIST_FOLDER, PRIVATE_PLAYLIST_FOLDER, RECORDINGS_FOLDER, CHANNEL_IMAGES_FOLDER, BACKGROUND_IMAGES_FOLDER]:
    if not os.path.exists(folder):
        os.makedirs(folder)

###################################
# Configuration Functions
###################################
def load_config():
    default = {
        "load_increment": 1500,
        "theme": "Dark",
        "TMDB_API_KEY": "21c869343c05f40c57b28ce8eb50b81e",
        "download_channel_images": False
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
            if "download_channel_images" in config and isinstance(config["download_channel_images"], str):
                config["download_channel_images"] = config["download_channel_images"].lower() == "true"
            return config
        except:
            return default
    else:
        save_config(default)
        return default

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

config = load_config()
TMDB_API_KEY = config.get("TMDB_API_KEY", "")
download_channel_images = config.get("download_channel_images", False)

###################################
# Enhanced TMDB Functions
###################################
class TMDBClient:
    BASE_URL = "https://api.themoviedb.org/3"
    
    def __init__(self, api_key):
        self.api_key = api_key
        
    def search_media(self, query, media_type="movie"):
        url = f"{self.BASE_URL}/search/{media_type}"
        params = {
            "api_key": self.api_key,
            "query": query,
            "language": "en-US"
        }
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json().get("results", [])[:5]  # Return top 5 results
        except Exception as e:
            print(f"TMDB Error: {e}")
            return []
        
    def get_details(self, tmdb_id, media_type="movie"):
        url = f"{self.BASE_URL}/{media_type}/{tmdb_id}"
        params = {"api_key": self.api_key}
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            return {
                "title": data.get("title") or data.get("name"),
                "overview": data.get("overview"),
                "poster_path": f"https://image.tmdb.org/t/p/w500{data.get('poster_path')}",
                "backdrop_path": f"https://image.tmdb.org/t/p/w1280{data.get('backdrop_path')}",
                "release_date": data.get("release_date") or data.get("first_air_date"),
                "rating": data.get("vote_average"),
                "media_type": media_type
            }
        except Exception as e:
            print(f"TMDB Error: {e}")
            return {}

tmdb_client = TMDBClient(TMDB_API_KEY)

###################################
# Enhanced EPG Tab with Search
###################################
class EPGTabWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.current_channel = None
        
        # Search Box
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search EPG...")
        self.search_box.textChanged.connect(self.filter_epg)
        self.layout.addWidget(self.search_box)
        
        # EPG Table
        self.table = QTableWidget()
        self.layout.addWidget(self.table)
        self.programmes = []
        self.load_epg_data()
        
    def load_epg_data(self):
        self.programmes = fetch_epg_data()
        self.populate_table(self.programmes)
        
    def filter_epg(self):
        query = self.search_box.text().lower()
        filtered = [p for p in self.programmes if query in p["channel"].lower() or query in p["title"].lower()]
        self.populate_table(filtered)
        
    def populate_table(self, programmes):
        self.table.clear()
        if not programmes:
            return
            
        channels = sorted({p["channel"] for p in programmes})
        now = datetime.datetime.now()
        grid_start = now.replace(minute=0, second=0, microsecond=0)
        grid_end = grid_start + datetime.timedelta(hours=6)
        time_slots = [grid_start + datetime.timedelta(minutes=30*i) for i in range(12)]
        
        self.table.setRowCount(len(channels))
        self.table.setColumnCount(len(time_slots))
        self.table.setHorizontalHeaderLabels([t.strftime("%H:%M") for t in time_slots])
        self.table.setVerticalHeaderLabels(channels)
        
        channel_to_row = {chan: i for i, chan in enumerate(channels)}
        for prog in programmes:
            prog_start = parse_xmltv_time(prog["start"])
            prog_stop = parse_xmltv_time(prog["stop"])
            if not prog_start or not prog_stop:
                continue
                
            row = channel_to_row.get(prog["channel"])
            col_start = (prog_start - grid_start).seconds // 1800
            col_span = (prog_stop - prog_start).seconds // 1800
            
            if 0 <= col_start < self.table.columnCount():
                item = QTableWidgetItem(f"{prog['title']}\n{prog_start.strftime('%H:%M')}-{prog_stop.strftime('%H:%M')}")
                if prog_start <= now <= prog_stop:
                    item.setBackground(QtGui.QColor("#ffcccb"))
                    if self.current_channel == prog["channel"]:
                        item.setBackground(QtGui.QColor("#90EE90"))
                self.table.setItem(row, col_start, item)
                self.table.setSpan(row, col_start, 1, col_span)

###################################
# Enhanced Status Bar Management
###################################
class EnhancedStatusBar(QStatusBar):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.playing_label = QLabel()
        self.stats_label = QLabel()
        self.addWidget(self.playing_label)
        self.addPermanentWidget(self.stats_label)
        
    def update_playing_info(self, text):
        self.playing_label.setText(f"Now Playing: {text}")
        
    def update_stats(self, text):
        self.stats_label.setText(text)

###################################
# System Stats Thread (Fixed)
###################################
class SystemStatsThread(QtCore.QThread):
    stats_updated = QtCore.pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.running = True
        
    def run(self):
        prev_net = psutil.net_io_counters().bytes_recv
        while self.running:
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            cur_net = psutil.net_io_counters().bytes_recv
            bitrate = int((cur_net - prev_net) / 1024)
            prev_net = cur_net
            stats = f"Bitrate: {bitrate} KB/s | CPU: {cpu}% | Mem: {mem}%"
            self.stats_updated.emit(stats)
            time.sleep(2)
            
    def stop(self):
        self.running = False

###################################
# Main IPTVPlayer Updates
###################################
class IPTVPlayer(QMainWindow):
    def __init__(self):
        super().__init__()
        # ... (existing initialization code)
        
        # Replace status bar
        self.statusBar().deleteLater()
        self.status_bar = EnhancedStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add TMDB metadata handling to playback
        self.current_media_info = {}
        
    def play_stream(self, url, channel_info=None):
        if channel_info:
            self.current_channel = channel_info.get("name", "Unknown Channel")
            self.status_bar.update_playing_info(self.current_channel)
            
            # Fetch TMDB metadata
            results = tmdb_client.search_media(channel_info.get("name"))
            if results:
                details = tmdb_client.get_details(results[0]["id"], results[0]["media_type"])
                self.current_media_info = details
                if details.get("backdrop_path"):
                    pixmap = download_image(details["backdrop_path"], BACKGROUND_IMAGES_FOLDER)
                    self.set_background_image(pixmap)
        # ... rest of playback code
    
    def closeEvent(self, event):
        self.stats_thread.stop()
        super().closeEvent(event)

# ... (rest of the original code with these updates integrated)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(BOOTSTRAP_QSS)
    window = IPTVPlayer()
    window.show()
    sys.exit(app.exec())