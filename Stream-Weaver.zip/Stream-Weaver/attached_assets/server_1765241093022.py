from flask import Flask, request
from flask_socketio import SocketIO, emit

app = Flask(__name__)
# Allow all CORS origins for testing; adjust in production.
socketio = SocketIO(app, cors_allowed_origins="*")

@socketio.on('connect')
def handle_connect():
    print("Client connected:", request.sid)
    emit('chat_message', {'username': 'Server', 'message': 'Welcome to IPTVking Chat!'})

@socketio.on('disconnect')
def handle_disconnect():
    print("Client disconnected:", request.sid)

@socketio.on('chat_message')
def handle_chat_message(data):
    print("Chat message received:", data)
    # Broadcast the chat message to all clients.
    emit('chat_message', data, broadcast=True)

@socketio.on('sync')
def handle_sync(data):
    print("Sync event received:", data)
    # Broadcast the sync event to all clients.
    emit('sync', data, broadcast=True)

if __name__ == '__main__':
    # Run the server on 0.0.0.0 so it listens on all interfaces, port 5000.
    socketio.run(app, host="0.0.0.0", port=5000)
