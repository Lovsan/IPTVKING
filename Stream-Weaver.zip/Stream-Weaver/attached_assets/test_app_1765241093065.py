import sys
import os
import json
import psutil
import time
from datetime import datetime
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtGui import QFont, QColor, QPalette
import requests

from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QTextEdit, QLabel, 
                             QListWidget, QSplitter, QTabWidget, QLineEdit,
                             QMessageBox, QProgressBar)


class ResourceMonitor(QThread):
    """Monitor system resources during player tests"""
    resource_update = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        self.running = False
        
    def run(self):
        self.running = True
        while self.running:
            cpu = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory().percent
            self.resource_update.emit({
                'cpu': cpu,
                'memory': memory,
                'timestamp': datetime.now().strftime('%H:%M:%S')
            })
            time.sleep(1)
    
    def stop(self):
        self.running = False


class OllamaInterface:
    """Interface to Ollama AI for code analysis"""
    def __init__(self, base_url="http://localhost:11434"):
        self.base_url = base_url
    
    def analyze_code(self, code, issue_type="general"):
        """Send code to Ollama for analysis"""
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": "codellama",
                    "prompt": f"Analyze this code for {issue_type} issues:\n\n{code}\n\nProvide specific issues found:",
                    "stream": False
                },
                timeout=30
            )
            if response.status_code == 200:
                return response.json().get('response', 'No response')
            return None
        except Exception as e:
            return f"Ollama connection error: {str(e)}"


class IssueTracker:
    """Backend storage for issues"""
    def __init__(self, db_file="issues.json"):
        self.db_file = db_file
        self.load_issues()
    
    def load_issues(self):
        """Load issues from JSON file"""
        if os.path.exists(self.db_file):
            with open(self.db_file, 'r') as f:
                self.issues = json.load(f)
        else:
            self.issues = []
    
    def save_issues(self):
        """Save issues to JSON file"""
        with open(self.db_file, 'w') as f:
            json.dump(self.issues, indent=2, fp=f)
    
    def add_issue(self, title, description, file_path, code_snippet, severity="medium"):
        """Add new issue"""
        issue = {
            'id': len(self.issues) + 1,
            'title': title,
            'description': description,
            'file_path': file_path,
            'code_snippet': code_snippet,
            'severity': severity,
            'timestamp': datetime.now().isoformat(),
            'comments': [],
            'status': 'open'
        }
        self.issues.append(issue)
        self.save_issues()
        return issue
    
    def add_comment(self, issue_id, comment):
        """Add comment to an issue"""
        for issue in self.issues:
            if issue['id'] == issue_id:
                issue['comments'].append({
                    'text': comment,
                    'timestamp': datetime.now().isoformat()
                })
                self.save_issues()
                return True
        return False


class CodeEditor(QWidget):
    """Code editor with syntax highlighting and edit capabilities"""
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        
        self.file_label = QLabel("No file loaded")
        layout.addWidget(self.file_label)
        
        self.editor = QTextEdit()
        self.editor.setFont(QFont("Courier New", 10))
        layout.addWidget(self.editor)
        
        btn_layout = QHBoxLayout()
        self.save_btn = QPushButton("Save Changes")
        self.save_btn.clicked.connect(self.save_file)
        btn_layout.addWidget(self.save_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.current_file = None
    
    def load_file(self, file_path):
        """Load file into editor"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            self.editor.setPlainText(content)
            self.file_label.setText(f"Editing: {file_path}")
            self.current_file = file_path
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not load file: {str(e)}")
    
    def save_file(self):
        """Save edited content back to file"""
        if self.current_file:
            try:
                with open(self.current_file, 'w', encoding='utf-8') as f:
                    f.write(self.editor.toPlainText())
                QMessageBox.information(self, "Success", "File saved successfully!")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not save file: {str(e)}")


class IssuesPanel(QWidget):
    """Discord-style issues panel"""
    def __init__(self, tracker):
        super().__init__()
        self.tracker = tracker
        
        layout = QHBoxLayout()
        
        # Left side - Issue list
        left_panel = QVBoxLayout()
        self.issue_list = QListWidget()
        self.issue_list.itemClicked.connect(self.show_issue_detail)
        left_panel.addWidget(QLabel("📋 Issues"))
        left_panel.addWidget(self.issue_list)
        
        # Right side - Issue detail
        right_panel = QVBoxLayout()
        self.detail_view = QTextEdit()
        self.detail_view.setReadOnly(True)
        right_panel.addWidget(QLabel("💬 Issue Details"))
        right_panel.addWidget(self.detail_view)
        
        self.comment_input = QLineEdit()
        self.comment_input.setPlaceholderText("Add a comment...")
        self.add_comment_btn = QPushButton("Add Comment")
        self.add_comment_btn.clicked.connect(self.add_comment)
        right_panel.addWidget(self.comment_input)
        right_panel.addWidget(self.add_comment_btn)
        
        splitter = QSplitter(Qt.Horizontal)
        left_widget = QWidget()
        left_widget.setLayout(left_panel)
        right_widget = QWidget()
        right_widget.setLayout(right_panel)
        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(1, 2)
        
        layout.addWidget(splitter)
        self.setLayout(layout)
        self.refresh_issues()
        self.current_issue = None
    
    def refresh_issues(self):
        """Refresh issue list"""
        self.issue_list.clear()
        for issue in self.tracker.issues:
            severity_icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(issue['severity'], "⚪")
            self.issue_list.addItem(f"{severity_icon} [{issue['id']}] {issue['title']}")
    
    def show_issue_detail(self, item):
        """Show detailed issue view"""
        issue_id = int(item.text().split('[')[1].split(']')[0])
        for issue in self.tracker.issues:
            if issue['id'] == issue_id:
                self.current_issue = issue
                detail_text = f"""
                                <h2>{issue['title']}</h2>
                                <p><b>Status:</b> {issue['status']} | <b>Severity:</b> {issue['severity']}</p>
                                <p><b>File:</b> {issue['file_path']}</p>
                                <p><b>Time:</b> {issue['timestamp']}</p>
                                <hr>
                                <h3>Description:</h3>
                                <p>{issue['description']}</p>
                                <h3>Code Snippet:</h3>
                                <pre style="background:#2b2b2b;padding:10px;border-radius:5px;">{issue['code_snippet']}</pre>
                                <hr>
                                <h3>Comments ({len(issue['comments'])}):</h3>
                                """
                for comment in issue['comments']:
                    detail_text += f"<p><b>{comment['timestamp']}</b><br>{comment['text']}</p>"
                
                self.detail_view.setHtml(detail_text)
                break
    
    def add_comment(self):
        """Add comment to current issue"""
        if self.current_issue and self.comment_input.text():
            self.tracker.add_comment(self.current_issue['id'], self.comment_input.text())
            self.comment_input.clear()
            self.show_issue_detail(self.issue_list.currentItem())


class TestApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("IPTV King - Professional Testing Suite")
        self.setGeometry(100, 100, 1400, 900)
        
        # Apply dark theme
        self.apply_dark_theme()
        
        # Initialize components
        self.tracker = IssueTracker()
        self.ollama = OllamaInterface()
        self.resource_monitor = ResourceMonitor()
        self.resource_monitor.resource_update.connect(self.update_resources)
        
        # Central widget with tabs
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        
        # Tab 1: Main Testing
        self.main_tab = self.create_main_tab()
        self.tabs.addTab(self.main_tab, "🧪 Testing")
        
        # Tab 2: Issues (Discord-style)
        self.issues_panel = IssuesPanel(self.tracker)
        self.tabs.addTab(self.issues_panel, "📋 Issues")
        
        # Tab 3: Code Editor
        self.code_editor = CodeEditor()
        self.tabs.addTab(self.code_editor, "📝 Editor")
        
        # Tab 4: Reports
        self.reports_tab = self.create_reports_tab()
        self.tabs.addTab(self.reports_tab, "📊 Reports")
        
        # Generate initial report
        self.generate_session_report()
    
    def apply_dark_theme(self):
        """Apply professional dark theme"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(30, 30, 30))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(45, 45, 45))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        self.setPalette(palette)
    
    def create_main_tab(self):
        """Create main testing tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Resource monitoring
        self.resource_label = QLabel("CPU: 0% | Memory: 0%")
        self.resource_label.setFont(QFont("Arial", 12, QFont.Bold))
        layout.addWidget(self.resource_label)
        
        # Progress bar
        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        
        # Console output
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Courier New", 10))
        layout.addWidget(self.console)
        
        # Control buttons
        btn_layout = QHBoxLayout()
        self.start_test_btn = QPushButton("🚀 Run All Tests")
        self.start_test_btn.clicked.connect(self.run_tests)
        self.player_test_btn = QPushButton("🎬 Test 4 Players")
        self.player_test_btn.clicked.connect(self.test_players)
        btn_layout.addWidget(self.start_test_btn)
        btn_layout.addWidget(self.player_test_btn)
        layout.addLayout(btn_layout)
        
        widget.setLayout(layout)
        return widget
    
    def create_reports_tab(self):
        """Create reports tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        self.report_view = QTextEdit()
        self.report_view.setReadOnly(True)
        layout.addWidget(self.report_view)
        widget.setLayout(layout)
        return widget
    
    def log(self, message, level="INFO"):
        """Log message to console"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        color = {"INFO": "lightblue", "ERROR": "red", "SUCCESS": "lightgreen", "WARNING": "yellow"}.get(level, "white")
        self.console.append(f'<span style="color:{color}">[{timestamp}] {level}: {message}</span>')
    
    def update_resources(self, data):
        """Update resource monitoring display"""
        self.resource_label.setText(f"CPU: {data['cpu']:.1f}% | Memory: {data['memory']:.1f}%")
    
    def run_tests(self):
        """Run comprehensive tests"""
        self.log("Starting comprehensive test suite...", "INFO")
        self.resource_monitor.start()
        self.progress.setValue(0)
        
        # Simulate testing all Python files in directory
        python_files = [f for f in os.listdir('.') if f.endswith('.py')]
        total_files = len(python_files)
        
        for i, file in enumerate(python_files):
            self.log(f"Analyzing {file}...", "INFO")
            try:
                with open(file, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                # Ollama analysis
                analysis = self.ollama.analyze_code(code[:1000], "syntax and logic")
                if analysis and "error" not in analysis.lower():
                    self.tracker.add_issue(
                        f"Issues in {file}",
                        analysis,
                        file,
                        code[:200],
                        "medium"
                    )
                    self.log(f"Issues found in {file}", "WARNING")
                else:
                    self.log(f"{file} passed checks", "SUCCESS")
                
            except Exception as e:
                self.log(f"Error analyzing {file}: {str(e)}", "ERROR")
            
            self.progress.setValue(int((i + 1) / total_files * 100))
        
        self.issues_panel.refresh_issues()
        self.log("All tests completed!", "SUCCESS")
        self.generate_session_report()
    
    def test_players(self):
        """Test 4 players simultaneously"""
        self.log("Testing 4 concurrent players...", "INFO")
        self.resource_monitor.start()
        
        # Simulate player resource usage
        self.log("Player 1: Starting...", "INFO")
        self.log("Player 2: Starting...", "INFO")
        self.log("Player 3: Starting...", "INFO")
        self.log("Player 4: Starting...", "INFO")
        
        time.sleep(2)
        
        cpu = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory().percent
        
        self.log(f"Resource usage with 4 players - CPU: {cpu}%, Memory: {memory}%", "WARNING")
        self.tracker.add_issue(
            "4-Player Resource Test",
            f"CPU: {cpu}%, Memory: {memory}%",
            "player_test",
            "4 concurrent video players",
            "low"
        )
    
    def generate_session_report(self):
        """Generate professional session report"""
        report = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial; background: #1e1e1e; color: #fff; padding: 20px; }}
        h1 {{ color: #4CAF50; border-bottom: 2px solid #4CAF50; }}
        .section {{ background: #2b2b2b; padding: 15px; margin: 10px 0; border-radius: 8px; }}
        .stats {{ display: flex; justify-content: space-around; }}
        .stat-box {{ text-align: center; padding: 20px; background: #353535; border-radius: 5px; }}
        .stat-number {{ font-size: 32px; font-weight: bold; color: #4CAF50; }}
    </style>
</head>
<body>
    <h1>🎯 IPTV King Professional Test Report</h1>
    <div class="section">
        <h2>Session Information</h2>
        <p><b>Date:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p><b>User:</b> {os.getenv('USERNAME', 'Developer')}</p>
    </div>
    
    <div class="section">
        <h2>📊 Statistics</h2>
        <div class="stats">
            <div class="stat-box">
                <div class="stat-number">{len(self.tracker.issues)}</div>
                <div>Total Issues</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{psutil.cpu_percent()}%</div>
                <div>CPU Usage</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{psutil.virtual_memory().percent}%</div>
                <div>Memory Usage</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2>🔍 Recent Issues</h2>
        <ul>
"""
        for issue in self.tracker.issues[-5:]:
            report += f"<li>[{issue['severity'].upper()}] {issue['title']} - {issue['file_path']}</li>"
        
        report += """
        </ul>
    </div>
    
    <div class="section">
        <h2>✅ Recommendations</h2>
        <ul>
            <li>Review high-severity issues first</li>
            <li>Monitor resource usage during peak loads</li>
            <li>Consider code optimization for better performance</li>
            <li>Implement automated testing pipeline</li>
        </ul>
    </div>
    
    <footer style="text-align:center; margin-top:30px; color:#666;">
        <p>Generated by IPTV King Professional Testing Suite</p>
    </footer>
</body>
</html>
"""
        self.report_view.setHtml(report)
        
        # Save report to file
        with open(f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html", 'w') as f:
            f.write(report)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = TestApp()
    window.show()
    sys.exit(app.exec_())