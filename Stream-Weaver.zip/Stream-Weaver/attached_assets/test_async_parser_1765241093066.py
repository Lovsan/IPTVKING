"""
Quick test of the async parser functionality
"""

import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QThread
from utils.async_parser import PlaylistParserThread, StreamingM3UParser
import time

def test_streaming_parser():
    """Test the streaming parser"""
    print("Testing Streaming M3U Parser...")
    
    # Find a test playlist
    import os
    playlist_dir = "playlists"
    if not os.path.exists(playlist_dir):
        print(f"No playlists directory found at {playlist_dir}")
        return
    
    playlists = [f for f in os.listdir(playlist_dir) if f.endswith(('.m3u', '.m3u8'))]
    if not playlists:
        print("No playlists found")
        return
    
    test_file = os.path.join(playlist_dir, playlists[0])
    print(f"Testing with: {test_file}")
    
    # Count channels
    print("Counting channels...")
    start = time.time()
    count = StreamingM3UParser.count_channels(test_file)
    print(f"Total channels: {count:,} (counted in {time.time() - start:.2f}s)")
    
    # Parse in chunks
    print("\nParsing in chunks...")
    start = time.time()
    chunks_parsed = 0
    channels_parsed = 0
    
    for chunk in StreamingM3UParser.parse_stream(test_file, chunk_size=1000):
        chunks_parsed += 1
        channels_parsed += len(chunk)
        if chunks_parsed <= 3 or chunks_parsed % 10 == 0:
            print(f"  Chunk {chunks_parsed}: {len(chunk)} channels (total: {channels_parsed:,})")
    
    elapsed = time.time() - start
    print(f"\nCompleted: {channels_parsed:,} channels in {chunks_parsed} chunks")
    print(f"Time: {elapsed:.2f}s ({channels_parsed/elapsed:.0f} channels/sec)")
    
    return test_file, channels_parsed


def test_threaded_parser(test_file):
    """Test the threaded parser with Qt"""
    print("\n" + "="*60)
    print("Testing Threaded Parser (with Qt)...")
    
    app = QApplication(sys.argv)
    
    class TestReceiver:
        def __init__(self):
            self.total_received = 0
            self.chunks_received = 0
            
        def on_progress(self, current, total):
            if current % 10000 == 0 or current == total:
                print(f"  Progress: {current:,} / {total:,} ({current*100//total}%)")
        
        def on_chunk(self, chunk):
            self.chunks_received += 1
            self.total_received += len(chunk)
        
        def on_finished(self, total):
            print(f"Finished! Total: {total:,} channels in {self.chunks_received} chunks")
            app.quit()
        
        def on_error(self, msg):
            print(f"Error: {msg}")
            app.quit()
    
    receiver = TestReceiver()
    
    # Create and start parser thread
    print(f"Starting parser for: {test_file}")
    start = time.time()
    
    parser = PlaylistParserThread(test_file, use_cache=False, chunk_size=1000)
    parser.progress.connect(receiver.on_progress)
    parser.chunk_ready.connect(receiver.on_chunk)
    parser.finished.connect(receiver.on_finished)
    parser.error.connect(receiver.on_error)
    parser.start()
    
    # Run event loop
    app.exec()
    
    elapsed = time.time() - start
    print(f"Time: {elapsed:.2f}s ({receiver.total_received/elapsed:.0f} channels/sec)")
    
    # Test with cache
    print("\n" + "="*60)
    print("Testing with cache enabled...")
    
    receiver2 = TestReceiver()
    parser2 = PlaylistParserThread(test_file, use_cache=True, chunk_size=1000)
    parser2.progress.connect(receiver2.on_progress)
    parser2.chunk_ready.connect(receiver2.on_chunk)
    parser2.finished.connect(receiver2.on_finished)
    parser2.error.connect(receiver2.on_error)
    
    start = time.time()
    parser2.start()
    app.exec()
    elapsed = time.time() - start
    print(f"Time with cache: {elapsed:.2f}s ({receiver2.total_received/elapsed:.0f} channels/sec)")


if __name__ == '__main__':
    try:
        test_file, count = test_streaming_parser()
        if test_file:
            test_threaded_parser(test_file)
    except KeyboardInterrupt:
        print("\nTest interrupted")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
