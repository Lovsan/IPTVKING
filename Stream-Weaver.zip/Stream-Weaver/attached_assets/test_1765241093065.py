# [file name]: test_logging.py
# [file content begin]
"""
Test suite for logging system
"""

import logging
import pytest
from pathlib import Path
from config.logging_config import LoggingConfig

def test_logging_setup():
    """Test that logging system can be setup"""
    logger = LoggingConfig.setup_logging()
    assert logger is not None
    assert isinstance(logger, logging.Logger)

def test_logger_creation():
    """Test that loggers can be created for different modules"""
    test_logger = LoggingConfig.get_logger('test.module')
    assert test_logger.name == 'test.module'
    assert test_logger.level == logging.DEBUG

def test_logging_levels():
    """Test that different log levels work"""
    logger = LoggingConfig.get_logger('test.levels')
    
    # These should not raise exceptions
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    logger.critical("Critical message")

def test_log_file_creation():
    """Test that log files are created"""
    from config.settings import AppConfig
    
    logs_dir = AppConfig.DATA_DIR / 'logs'
    assert logs_dir.exists()
    
    log_files = list(logs_dir.glob('iptvking_*.log'))
    assert len(log_files) > 0

if __name__ == '__main__':
    # Run logging tests
    test_logging_setup()
    test_logger_creation()
    test_logging_levels()
    test_log_file_creation()
    print("✅ All logging tests passed!")
# [file content end]