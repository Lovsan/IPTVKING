import { EpgGrid } from "@/components/epg-grid";
import type { Channel, EpgProgram } from "@shared/schema";

interface EpgPageProps {
  channels: Channel[];
  programs: EpgProgram[];
  currentChannelId?: string;
  onSelectProgram: (program: EpgProgram, channel: Channel) => void;
  onPlayChannel: (channel: Channel) => void;
}

export function EpgPage({
  channels,
  programs,
  currentChannelId,
  onSelectProgram,
  onPlayChannel,
}: EpgPageProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">EPG Guide</h1>
      </div>
      <div className="flex-1 min-h-0">
        <EpgGrid
          channels={channels}
          programs={programs}
          currentChannelId={currentChannelId}
          onSelectProgram={onSelectProgram}
          onPlayChannel={onPlayChannel}
        />
      </div>
    </div>
  );
}
