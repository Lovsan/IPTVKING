import { useState } from "react";
import { Link } from "wouter";
import {
  Play,
  Tv,
  Calendar,
  Heart,
  TrendingUp,
  Clock,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import type { Channel, Playlist } from "@shared/schema";

interface HomePageProps {
  channels: Channel[];
  playlists: Playlist[];
  favoriteChannels: Channel[];
  recentChannels: Channel[];
  onPlayChannel: (channel: Channel) => void;
}

export function HomePage({
  channels,
  playlists,
  favoriteChannels,
  recentChannels,
  onPlayChannel,
}: HomePageProps) {
  const featuredChannel = channels.length > 0 ? channels[0] : null;
  const activePlaylist = playlists.find((p) => p.isActive);

  return (
    <div className="flex flex-col h-full">
      {featuredChannel ? (
        <div className="relative h-64 md:h-80 rounded-lg overflow-hidden mb-6">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-primary/10 to-transparent" />
          {featuredChannel.logo && (
            <img
              src={featuredChannel.logo}
              alt={featuredChannel.name}
              className="absolute inset-0 w-full h-full object-cover opacity-20"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />

          <div className="absolute bottom-0 left-0 right-0 p-6">
            <Badge className="mb-3 bg-red-500">LIVE NOW</Badge>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">
              {featuredChannel.name}
            </h1>
            {featuredChannel.group && (
              <p className="text-muted-foreground mb-4">
                {featuredChannel.group}
              </p>
            )}
            <div className="flex items-center gap-3">
              <Button
                size="lg"
                onClick={() => onPlayChannel(featuredChannel)}
                data-testid="button-play-featured"
              >
                <Play className="w-5 h-5 mr-2 fill-current" />
                Watch Now
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/channels" data-testid="link-browse-channels">
                  Browse Channels
                </Link>
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="relative h-64 md:h-80 rounded-lg overflow-hidden mb-6 bg-gradient-to-br from-primary/20 to-muted flex items-center justify-center">
          <div className="text-center">
            <Tv className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
            <h1 className="text-2xl font-bold mb-2">Welcome to IPTVking</h1>
            <p className="text-muted-foreground mb-4">
              Upload a playlist to get started
            </p>
            <Button asChild data-testid="button-go-to-playlists">
              <Link href="/playlists">
                Add Playlist
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="hover-elevate cursor-pointer">
          <Link href="/channels">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                <Tv className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium">Live TV</p>
                <p className="text-xs text-muted-foreground">
                  {channels.length} channels
                </p>
              </div>
            </CardContent>
          </Link>
        </Card>

        <Card className="hover-elevate cursor-pointer">
          <Link href="/epg">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-md bg-accent/20 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="font-medium">EPG Guide</p>
                <p className="text-xs text-muted-foreground">Program schedule</p>
              </div>
            </CardContent>
          </Link>
        </Card>

        <Card className="hover-elevate cursor-pointer">
          <Link href="/favorites">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-md bg-red-500/10 flex items-center justify-center">
                <Heart className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="font-medium">Favorites</p>
                <p className="text-xs text-muted-foreground">
                  {favoriteChannels.length} channels
                </p>
              </div>
            </CardContent>
          </Link>
        </Card>

        <Card className="hover-elevate cursor-pointer">
          <Link href="/multiview">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-md bg-blue-500/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="font-medium">Multi-View</p>
                <p className="text-xs text-muted-foreground">Watch 4 streams</p>
              </div>
            </CardContent>
          </Link>
        </Card>
      </div>

      {recentChannels.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Continue Watching
            </h2>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/channels">
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </div>
          <ScrollArea className="w-full">
            <div className="flex gap-4 pb-4">
              {recentChannels.slice(0, 8).map((channel) => (
                <Card
                  key={channel.id}
                  className="w-40 flex-shrink-0 cursor-pointer hover-elevate"
                  onClick={() => onPlayChannel(channel)}
                  data-testid={`card-recent-${channel.id}`}
                >
                  <div className="aspect-square bg-muted rounded-t-md flex items-center justify-center overflow-hidden">
                    {channel.logo ? (
                      <img
                        src={channel.logo}
                        alt={channel.name}
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <Tv className="w-10 h-10 text-muted-foreground/30" />
                    )}
                  </div>
                  <CardContent className="p-3">
                    <p className="font-medium text-sm truncate">{channel.name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      )}

      {favoriteChannels.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500" />
              Favorites
            </h2>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/favorites">
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </div>
          <ScrollArea className="w-full">
            <div className="flex gap-4 pb-4">
              {favoriteChannels.slice(0, 8).map((channel) => (
                <Card
                  key={channel.id}
                  className="w-40 flex-shrink-0 cursor-pointer hover-elevate"
                  onClick={() => onPlayChannel(channel)}
                  data-testid={`card-favorite-${channel.id}`}
                >
                  <div className="aspect-square bg-muted rounded-t-md flex items-center justify-center overflow-hidden">
                    {channel.logo ? (
                      <img
                        src={channel.logo}
                        alt={channel.name}
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <Tv className="w-10 h-10 text-muted-foreground/30" />
                    )}
                  </div>
                  <CardContent className="p-3">
                    <p className="font-medium text-sm truncate">{channel.name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      )}

      {activePlaylist && (
        <div className="mt-auto pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            Active playlist:{" "}
            <span className="font-medium text-foreground">
              {activePlaylist.name}
            </span>{" "}
            ({activePlaylist.channelCount || 0} channels)
          </p>
        </div>
      )}
    </div>
  );
}
