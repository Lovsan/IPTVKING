import { MultiViewPlayer } from "@/components/multi-view-player";
import { ChannelBrowser } from "@/components/channel-browser";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tv, List } from "lucide-react";
import type { Channel, PlayerState } from "@shared/schema";

interface MultiViewPageProps {
  channels: Channel[];
  players: PlayerState[];
  onPlayChannel: (playerId: number, channel: Channel) => void;
  onTogglePlay: (playerId: number) => void;
  onVolumeChange: (playerId: number, volume: number) => void;
  onToggleMute: (playerId: number) => void;
  onSetActivePlayer: (playerId: number) => void;
  onClosePlayer: (playerId: number) => void;
  onToggleFavorite: (channel: Channel) => void;
  activePlayerId: number;
}

export function MultiViewPage({
  channels,
  players,
  onPlayChannel,
  onTogglePlay,
  onVolumeChange,
  onToggleMute,
  onSetActivePlayer,
  onClosePlayer,
  onToggleFavorite,
  activePlayerId,
}: MultiViewPageProps) {
  const handlePlayChannel = (channel: Channel) => {
    onPlayChannel(activePlayerId, channel);
  };

  return (
    <div className="flex flex-col h-full gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Multi-View</h1>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">
        <div className="lg:col-span-2">
          <MultiViewPlayer
            players={players}
            onPlayChannel={onPlayChannel}
            onTogglePlay={onTogglePlay}
            onVolumeChange={onVolumeChange}
            onToggleMute={onToggleMute}
            onSetActivePlayer={onSetActivePlayer}
            onClosePlayer={onClosePlayer}
          />
        </div>

        <Card className="p-4 overflow-hidden">
          <Tabs defaultValue="channels" className="h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="channels" data-testid="tab-multiview-channels">
                <Tv className="w-4 h-4 mr-2" />
                Channels
              </TabsTrigger>
              <TabsTrigger value="info" data-testid="tab-multiview-info">
                <List className="w-4 h-4 mr-2" />
                Info
              </TabsTrigger>
            </TabsList>

            <TabsContent value="channels" className="flex-1 overflow-hidden mt-0">
              <ChannelBrowser
                channels={channels}
                onPlayChannel={handlePlayChannel}
                onToggleFavorite={onToggleFavorite}
              />
            </TabsContent>

            <TabsContent value="info" className="flex-1 mt-0">
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Active Players</h3>
                  <div className="space-y-2">
                    {players.map((player) => (
                      <div
                        key={player.id}
                        className={`p-3 rounded-md ${
                          player.isActive
                            ? "bg-primary/10 border border-primary"
                            : "bg-muted"
                        }`}
                      >
                        <p className="font-medium text-sm">
                          Player {player.id + 1}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {player.channel
                            ? player.channel.name
                            : "No channel selected"}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Tips</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>Click a player to make it active</li>
                    <li>Select a channel to play in the active player</li>
                    <li>Use the view buttons to change layout</li>
                    <li>Enable sync to control all players at once</li>
                  </ul>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}
