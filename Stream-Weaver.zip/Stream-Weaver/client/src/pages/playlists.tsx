import { PlaylistManager } from "@/components/playlist-manager";
import type { Playlist } from "@shared/schema";

interface PlaylistsPageProps {
  playlists: Playlist[];
  activePlaylistId?: string;
  onUploadFile: (file: File) => Promise<void>;
  onAddUrl: (url: string, name: string) => Promise<void>;
  onActivatePlaylist: (playlistId: string) => void;
  onDeletePlaylist: (playlistId: string) => void;
  isUploading?: boolean;
  uploadProgress?: number;
}

export function PlaylistsPage({
  playlists,
  activePlaylistId,
  onUploadFile,
  onAddUrl,
  onActivatePlaylist,
  onDeletePlaylist,
  isUploading,
  uploadProgress,
}: PlaylistsPageProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Playlists</h1>
      </div>
      <div className="flex-1">
        <PlaylistManager
          playlists={playlists}
          activePlaylistId={activePlaylistId}
          onUploadFile={onUploadFile}
          onAddUrl={onAddUrl}
          onActivatePlaylist={onActivatePlaylist}
          onDeletePlaylist={onDeletePlaylist}
          isUploading={isUploading}
          uploadProgress={uploadProgress}
        />
      </div>
    </div>
  );
}
