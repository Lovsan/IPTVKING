import { Heart, Tv } from "lucide-react";
import { ChannelBrowser } from "@/components/channel-browser";
import type { Channel } from "@shared/schema";

interface FavoritesPageProps {
  channels: Channel[];
  onPlayChannel: (channel: Channel) => void;
  onToggleFavorite: (channel: Channel) => void;
}

export function FavoritesPage({
  channels,
  onPlayChannel,
  onToggleFavorite,
}: FavoritesPageProps) {
  const favoriteChannels = channels.filter((c) => c.isFavorite);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Heart className="w-6 h-6 text-red-500" />
          Favorites
        </h1>
      </div>

      {favoriteChannels.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
          <Heart className="w-16 h-16 mb-4 opacity-30" />
          <p className="text-lg font-medium">No favorites yet</p>
          <p className="text-sm mt-1">
            Click the heart icon on any channel to add it to your favorites
          </p>
        </div>
      ) : (
        <div className="flex-1 min-h-0">
          <ChannelBrowser
            channels={favoriteChannels}
            onPlayChannel={onPlayChannel}
            onToggleFavorite={onToggleFavorite}
          />
        </div>
      )}
    </div>
  );
}
