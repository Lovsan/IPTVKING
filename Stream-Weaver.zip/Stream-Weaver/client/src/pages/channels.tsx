import { ChannelBrowser } from "@/components/channel-browser";
import type { Channel } from "@shared/schema";

interface ChannelsPageProps {
  channels: Channel[];
  onPlayChannel: (channel: Channel) => void;
  onToggleFavorite: (channel: Channel) => void;
  isLoading?: boolean;
}

export function ChannelsPage({
  channels,
  onPlayChannel,
  onToggleFavorite,
  isLoading,
}: ChannelsPageProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Live TV</h1>
      </div>
      <div className="flex-1 min-h-0">
        <ChannelBrowser
          channels={channels}
          onPlayChannel={onPlayChannel}
          onToggleFavorite={onToggleFavorite}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}
