import { useState, useMemo } from "react";
import { Search, Filter, Grid, List, Heart, Tv } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChannelCard } from "./channel-card";
import type { Channel } from "@shared/schema";

interface ChannelBrowserProps {
  channels: Channel[];
  onPlayChannel: (channel: Channel) => void;
  onToggleFavorite: (channel: Channel) => void;
  isLoading?: boolean;
}

type ViewMode = "grid" | "list";
type SortMode = "name" | "group" | "recent";

export function ChannelBrowser({
  channels,
  onPlayChannel,
  onToggleFavorite,
  isLoading = false,
}: ChannelBrowserProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGroup, setSelectedGroup] = useState<string>("all");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [sortMode, setSortMode] = useState<SortMode>("name");
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const groups = useMemo(() => {
    const uniqueGroups = new Set(channels.map((c) => c.group).filter(Boolean));
    return Array.from(uniqueGroups).sort();
  }, [channels]);

  const filteredChannels = useMemo(() => {
    let result = [...channels];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (c) =>
          c.name.toLowerCase().includes(query) ||
          c.group?.toLowerCase().includes(query)
      );
    }

    if (selectedGroup !== "all") {
      result = result.filter((c) => c.group === selectedGroup);
    }

    if (showFavoritesOnly) {
      result = result.filter((c) => c.isFavorite);
    }

    switch (sortMode) {
      case "name":
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case "group":
        result.sort((a, b) => (a.group || "").localeCompare(b.group || ""));
        break;
    }

    return result;
  }, [channels, searchQuery, selectedGroup, sortMode, showFavoritesOnly]);

  const favoriteCount = channels.filter((c) => c.isFavorite).length;

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
        <div className="animate-pulse">
          <Tv className="w-12 h-12 mb-4 opacity-50" />
        </div>
        <p>Loading channels...</p>
      </div>
    );
  }

  if (channels.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
        <Tv className="w-12 h-12 mb-4 opacity-30" />
        <p className="text-lg font-medium">No channels available</p>
        <p className="text-sm mt-1">Upload a playlist to get started</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex flex-col gap-3 mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search channels..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-channels"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={selectedGroup} onValueChange={setSelectedGroup}>
            <SelectTrigger className="w-[180px]" data-testid="select-group">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="All Groups" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Groups</SelectItem>
              {groups.map((group) => (
                <SelectItem key={group} value={group!}>
                  {group}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortMode} onValueChange={(v) => setSortMode(v as SortMode)}>
            <SelectTrigger className="w-[140px]" data-testid="select-sort">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="group">Group</SelectItem>
              <SelectItem value="recent">Recent</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant={showFavoritesOnly ? "default" : "outline"}
            size="sm"
            onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
            className="gap-1"
            data-testid="button-filter-favorites"
          >
            <Heart className={`w-4 h-4 ${showFavoritesOnly ? "fill-current" : ""}`} />
            Favorites
            {favoriteCount > 0 && (
              <Badge variant="secondary" className="ml-1">
                {favoriteCount}
              </Badge>
            )}
          </Button>

          <div className="flex-1" />

          <div className="flex items-center border rounded-md">
            <Button
              size="icon"
              variant={viewMode === "grid" ? "secondary" : "ghost"}
              onClick={() => setViewMode("grid")}
              className="rounded-r-none"
              data-testid="button-view-grid"
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant={viewMode === "list" ? "secondary" : "ghost"}
              onClick={() => setViewMode("list")}
              className="rounded-l-none"
              data-testid="button-view-list"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <p className="text-sm text-muted-foreground">
          {filteredChannels.length} channel{filteredChannels.length !== 1 ? "s" : ""}
          {searchQuery && ` matching "${searchQuery}"`}
        </p>
      </div>

      <ScrollArea className="flex-1">
        {viewMode === "grid" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 pb-4">
            {filteredChannels.map((channel) => (
              <ChannelCard
                key={channel.id}
                channel={channel}
                onPlay={onPlayChannel}
                onToggleFavorite={onToggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="space-y-2 pb-4">
            {filteredChannels.map((channel) => (
              <div
                key={channel.id}
                className="flex items-center gap-3 p-3 rounded-md bg-card hover-elevate cursor-pointer"
                onClick={() => onPlayChannel(channel)}
                data-testid={`list-channel-${channel.id}`}
              >
                <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center overflow-hidden">
                  {channel.logo ? (
                    <img
                      src={channel.logo}
                      alt={channel.name}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <Tv className="w-5 h-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{channel.name}</p>
                  {channel.group && (
                    <p className="text-xs text-muted-foreground truncate">
                      {channel.group}
                    </p>
                  )}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(channel);
                  }}
                  data-testid={`button-list-favorite-${channel.id}`}
                >
                  <Heart
                    className={`w-4 h-4 ${
                      channel.isFavorite ? "fill-red-500 text-red-500" : ""
                    }`}
                  />
                </Button>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
