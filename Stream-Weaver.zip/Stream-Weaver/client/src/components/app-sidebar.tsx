import { useLocation, Link } from "wouter";
import {
  Home,
  Tv,
  Calendar,
  Heart,
  List,
  Video,
  Settings,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";

interface AppSidebarProps {
  favoriteCount?: number;
  recordingCount?: number;
}

export function AppSidebar({
  favoriteCount = 0,
  recordingCount = 0,
}: AppSidebarProps) {
  const [location] = useLocation();

  const mainNavItems = [
    {
      title: "Home",
      url: "/",
      icon: Home,
    },
    {
      title: "Live TV",
      url: "/channels",
      icon: Tv,
    },
    {
      title: "EPG Guide",
      url: "/epg",
      icon: Calendar,
    },
    {
      title: "Multi-View",
      url: "/multiview",
      icon: Video,
    },
  ];

  const libraryItems = [
    {
      title: "Favorites",
      url: "/favorites",
      icon: Heart,
      badge: favoriteCount > 0 ? favoriteCount : undefined,
    },
    {
      title: "Playlists",
      url: "/playlists",
      icon: List,
    },
    {
      title: "Recordings",
      url: "/recordings",
      icon: Video,
      badge: recordingCount > 0 ? recordingCount : undefined,
    },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <Tv className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-bold text-lg">IPTVking</span>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={`nav-${item.title.toLowerCase().replace(" ", "-")}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Library</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {libraryItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={`nav-${item.title.toLowerCase()}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                      {item.badge && (
                        <Badge variant="secondary" className="ml-auto">
                          {item.badge}
                        </Badge>
                      )}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Tv className="w-4 h-4" />
          <span>IPTVking v1.0</span>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
