import { useState, useRef } from "react";
import {
  Upload,
  Link as LinkIcon,
  FileText,
  Trash2,
  Check,
  X,
  Loader2,
  List,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Playlist } from "@shared/schema";

interface PlaylistManagerProps {
  playlists: Playlist[];
  activePlaylistId?: string;
  onUploadFile: (file: File) => Promise<void>;
  onAddUrl: (url: string, name: string) => Promise<void>;
  onActivatePlaylist: (playlistId: string) => void;
  onDeletePlaylist: (playlistId: string) => void;
  isUploading?: boolean;
  uploadProgress?: number;
}

export function PlaylistManager({
  playlists,
  activePlaylistId,
  onUploadFile,
  onAddUrl,
  onActivatePlaylist,
  onDeletePlaylist,
  isUploading = false,
  uploadProgress = 0,
}: PlaylistManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    if (file.name.endsWith(".m3u") || file.name.endsWith(".m3u8")) {
      await onUploadFile(file);
      setIsOpen(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleUrlSubmit = async () => {
    if (urlInput.trim()) {
      await onAddUrl(urlInput.trim(), nameInput.trim() || "Untitled Playlist");
      setUrlInput("");
      setNameInput("");
      setIsOpen(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Playlists</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-add-playlist">
              <Upload className="w-4 h-4 mr-2" />
              Add Playlist
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Playlist</DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="file">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="file" data-testid="tab-upload-file">
                  <FileText className="w-4 h-4 mr-2" />
                  Upload File
                </TabsTrigger>
                <TabsTrigger value="url" data-testid="tab-add-url">
                  <LinkIcon className="w-4 h-4 mr-2" />
                  Add URL
                </TabsTrigger>
              </TabsList>

              <TabsContent value="file" className="mt-4">
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    isDragging
                      ? "border-primary bg-primary/5"
                      : "border-muted-foreground/25"
                  }`}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                >
                  {isUploading ? (
                    <div className="space-y-3">
                      <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">
                        Parsing playlist...
                      </p>
                      <Progress value={uploadProgress} className="w-full" />
                      <p className="text-xs text-muted-foreground">
                        Loading channels {Math.floor(uploadProgress)}%
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Drag and drop your M3U file here
                      </p>
                      <p className="text-xs text-muted-foreground mb-4">
                        or
                      </p>
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept=".m3u,.m3u8"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleFileSelect(file);
                        }}
                        data-testid="input-file-upload"
                      />
                      <Button
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        data-testid="button-browse-files"
                      >
                        Browse Files
                      </Button>
                    </>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="url" className="mt-4 space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Playlist Name
                  </label>
                  <Input
                    placeholder="My IPTV Playlist"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    data-testid="input-playlist-name"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    M3U URL
                  </label>
                  <Input
                    placeholder="https://example.com/playlist.m3u"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    data-testid="input-playlist-url"
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={handleUrlSubmit}
                  disabled={!urlInput.trim() || isUploading}
                  data-testid="button-add-url"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    <>
                      <LinkIcon className="w-4 h-4 mr-2" />
                      Add Playlist
                    </>
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>

      {playlists.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <List className="w-10 h-10 mb-3 opacity-30" />
            <p className="text-sm">No playlists added yet</p>
            <p className="text-xs mt-1">Upload an M3U file to get started</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {playlists.map((playlist) => (
            <Card
              key={playlist.id}
              className={`cursor-pointer hover-elevate ${
                playlist.id === activePlaylistId
                  ? "ring-2 ring-primary"
                  : ""
              }`}
              onClick={() => onActivatePlaylist(playlist.id)}
              data-testid={`card-playlist-${playlist.id}`}
            >
              <CardContent className="flex items-center gap-3 p-3">
                <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center">
                  <FileText className="w-5 h-5 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{playlist.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {playlist.channelCount || 0} channels
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {playlist.id === activePlaylistId && (
                    <Badge variant="default">
                      <Check className="w-3 h-3 mr-1" />
                      Active
                    </Badge>
                  )}
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeletePlaylist(playlist.id);
                    }}
                    data-testid={`button-delete-playlist-${playlist.id}`}
                  >
                    <Trash2 className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
