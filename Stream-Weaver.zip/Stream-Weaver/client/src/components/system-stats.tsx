import { Cpu, HardDrive, ArrowDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { SystemStats } from "@shared/schema";

interface SystemStatsDisplayProps {
  stats: SystemStats | null;
}

function getStatusColor(value: number): string {
  if (value < 50) return "text-green-500";
  if (value < 80) return "text-yellow-500";
  return "text-red-500";
}

export function SystemStatsDisplay({ stats }: SystemStatsDisplayProps) {
  if (!stats) {
    return (
      <div className="flex items-center gap-2">
        <Badge variant="secondary" className="font-mono text-xs">
          <Cpu className="w-3 h-3 mr-1" />
          CPU: --
        </Badge>
        <Badge variant="secondary" className="font-mono text-xs">
          <HardDrive className="w-3 h-3 mr-1" />
          Mem: --
        </Badge>
        <Badge variant="secondary" className="font-mono text-xs">
          <ArrowDown className="w-3 h-3 mr-1" />
          -- KB/s
        </Badge>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2" data-testid="system-stats">
      <Badge variant="secondary" className="font-mono text-xs">
        <Cpu className={`w-3 h-3 mr-1 ${getStatusColor(stats.cpu)}`} />
        CPU: {stats.cpu.toFixed(0)}%
      </Badge>
      <Badge variant="secondary" className="font-mono text-xs">
        <HardDrive className={`w-3 h-3 mr-1 ${getStatusColor(stats.memory)}`} />
        Mem: {stats.memory.toFixed(0)}%
      </Badge>
      <Badge variant="secondary" className="font-mono text-xs">
        <ArrowDown className="w-3 h-3 mr-1 text-primary" />
        {stats.bitrate.toFixed(1)} KB/s
      </Badge>
    </div>
  );
}
