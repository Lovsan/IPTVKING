import { Play, Heart, Star, Tv } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Channel } from "@shared/schema";

interface ChannelCardProps {
  channel: Channel;
  onPlay: (channel: Channel) => void;
  onToggleFavorite: (channel: Channel) => void;
  currentProgram?: string;
}

export function ChannelCard({
  channel,
  onPlay,
  onToggleFavorite,
  currentProgram,
}: ChannelCardProps) {
  return (
    <Card
      className="group relative overflow-visible hover-elevate active-elevate-2 cursor-pointer transition-transform duration-200"
      onClick={() => onPlay(channel)}
      data-testid={`card-channel-${channel.id}`}
    >
      <div className="aspect-square relative bg-gradient-to-br from-muted to-muted/50 rounded-t-md overflow-hidden">
        {channel.logo ? (
          <img
            src={channel.logo}
            alt={channel.name}
            className="w-full h-full object-contain p-4"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Tv className="w-12 h-12 text-muted-foreground/50" />
          </div>
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
        
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <Button
            size="icon"
            variant="default"
            className="rounded-full"
            onClick={(e) => {
              e.stopPropagation();
              onPlay(channel);
            }}
            data-testid={`button-play-${channel.id}`}
          >
            <Play className="w-5 h-5 fill-current" />
          </Button>
        </div>

        <Button
          size="icon"
          variant="ghost"
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(channel);
          }}
          data-testid={`button-favorite-${channel.id}`}
        >
          {channel.isFavorite ? (
            <Heart className="w-4 h-4 fill-red-500 text-red-500" />
          ) : (
            <Heart className="w-4 h-4" />
          )}
        </Button>
      </div>

      <div className="p-3">
        <h3 className="font-medium text-sm truncate" title={channel.name}>
          {channel.name}
        </h3>
        {channel.group && (
          <p className="text-xs text-muted-foreground truncate mt-0.5">
            {channel.group}
          </p>
        )}
        {currentProgram && (
          <Badge variant="secondary" className="mt-2 text-xs truncate max-w-full">
            <Star className="w-3 h-3 mr-1" />
            {currentProgram}
          </Badge>
        )}
      </div>
    </Card>
  );
}
