import { useState } from "react";
import {
  Settings,
  Monitor,
  Volume2,
  Wifi,
  Key,
  Info,
  Save,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTheme } from "@/lib/theme";

interface SettingsConfig {
  tmdbApiKey: string;
  autoPlay: boolean;
  defaultVolume: number;
  bufferSize: string;
  epgRefreshInterval: string;
  showSystemStats: boolean;
  enableSync: boolean;
}

interface SettingsPanelProps {
  config: SettingsConfig;
  onSave: (config: SettingsConfig) => void;
}

export function SettingsPanel({ config, onSave }: SettingsPanelProps) {
  const { theme, toggleTheme } = useTheme();
  const [localConfig, setLocalConfig] = useState<SettingsConfig>(config);
  const [isOpen, setIsOpen] = useState(false);

  const handleSave = () => {
    onSave(localConfig);
    setIsOpen(false);
  };

  const updateConfig = <K extends keyof SettingsConfig>(
    key: K,
    value: SettingsConfig[K]
  ) => {
    setLocalConfig((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" data-testid="button-settings">
          <Settings className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Settings
          </SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="general" className="mt-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="general" data-testid="tab-settings-general">
              <Monitor className="w-4 h-4" />
            </TabsTrigger>
            <TabsTrigger value="playback" data-testid="tab-settings-playback">
              <Volume2 className="w-4 h-4" />
            </TabsTrigger>
            <TabsTrigger value="network" data-testid="tab-settings-network">
              <Wifi className="w-4 h-4" />
            </TabsTrigger>
            <TabsTrigger value="api" data-testid="tab-settings-api">
              <Key className="w-4 h-4" />
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="mt-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Appearance</h3>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Dark Mode</Label>
                  <p className="text-xs text-muted-foreground">
                    Switch between light and dark themes
                  </p>
                </div>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={toggleTheme}
                  data-testid="switch-dark-mode"
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-sm font-medium">Display</h3>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Show System Stats</Label>
                  <p className="text-xs text-muted-foreground">
                    Display CPU, memory, and bitrate in header
                  </p>
                </div>
                <Switch
                  checked={localConfig.showSystemStats}
                  onCheckedChange={(v) => updateConfig("showSystemStats", v)}
                  data-testid="switch-system-stats"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="playback" className="mt-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Playback Settings</h3>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-Play</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically play channels when selected
                  </p>
                </div>
                <Switch
                  checked={localConfig.autoPlay}
                  onCheckedChange={(v) => updateConfig("autoPlay", v)}
                  data-testid="switch-auto-play"
                />
              </div>

              <div className="space-y-2">
                <Label>Default Volume</Label>
                <Select
                  value={String(localConfig.defaultVolume)}
                  onValueChange={(v) =>
                    updateConfig("defaultVolume", parseInt(v))
                  }
                >
                  <SelectTrigger data-testid="select-default-volume">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25">25%</SelectItem>
                    <SelectItem value="50">50%</SelectItem>
                    <SelectItem value="75">75%</SelectItem>
                    <SelectItem value="100">100%</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Buffer Size</Label>
                <Select
                  value={localConfig.bufferSize}
                  onValueChange={(v) => updateConfig("bufferSize", v)}
                >
                  <SelectTrigger data-testid="select-buffer-size">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low (faster start)</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High (smoother playback)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="network" className="mt-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Sync & Network</h3>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Real-time Sync</Label>
                  <p className="text-xs text-muted-foreground">
                    Sync playback across devices
                  </p>
                </div>
                <Switch
                  checked={localConfig.enableSync}
                  onCheckedChange={(v) => updateConfig("enableSync", v)}
                  data-testid="switch-enable-sync"
                />
              </div>

              <div className="space-y-2">
                <Label>EPG Refresh Interval</Label>
                <Select
                  value={localConfig.epgRefreshInterval}
                  onValueChange={(v) => updateConfig("epgRefreshInterval", v)}
                >
                  <SelectTrigger data-testid="select-epg-interval">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1h">Every hour</SelectItem>
                    <SelectItem value="6h">Every 6 hours</SelectItem>
                    <SelectItem value="12h">Every 12 hours</SelectItem>
                    <SelectItem value="24h">Every 24 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="api" className="mt-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">API Keys</h3>

              <div className="space-y-2">
                <Label>TMDB API Key</Label>
                <p className="text-xs text-muted-foreground mb-2">
                  Used for fetching movie and TV show metadata
                </p>
                <Input
                  type="password"
                  placeholder="Enter your TMDB API key"
                  value={localConfig.tmdbApiKey}
                  onChange={(e) => updateConfig("tmdbApiKey", e.target.value)}
                  data-testid="input-tmdb-api-key"
                />
              </div>
            </div>

            <Separator />

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Info className="w-4 h-4" />
              <p>Get your free TMDB API key at themoviedb.org</p>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Button className="w-full" onClick={handleSave} data-testid="button-save-settings">
            <Save className="w-4 h-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
