import { useState, useMemo, useRef } from "react";
import { Search, ChevronLeft, ChevronRight, Clock, Radio } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Channel, EpgProgram } from "@shared/schema";

interface EpgGridProps {
  channels: Channel[];
  programs: EpgProgram[];
  currentChannelId?: string;
  onSelectProgram: (program: EpgProgram, channel: Channel) => void;
  onPlayChannel: (channel: Channel) => void;
}

function parseTime(timeStr: string): Date {
  return new Date(timeStr);
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function isCurrentProgram(program: EpgProgram, now: Date): boolean {
  const start = parseTime(program.startTime);
  const end = parseTime(program.endTime);
  return now >= start && now <= end;
}

function getProgramWidth(program: EpgProgram, slotWidth: number): number {
  const start = parseTime(program.startTime);
  const end = parseTime(program.endTime);
  const durationMinutes = (end.getTime() - start.getTime()) / (1000 * 60);
  return (durationMinutes / 30) * slotWidth;
}

function getProgramOffset(
  program: EpgProgram,
  gridStart: Date,
  slotWidth: number
): number {
  const start = parseTime(program.startTime);
  const offsetMinutes = (start.getTime() - gridStart.getTime()) / (1000 * 60);
  return (offsetMinutes / 30) * slotWidth;
}

export function EpgGrid({
  channels,
  programs,
  currentChannelId,
  onSelectProgram,
  onPlayChannel,
}: EpgGridProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const scrollRef = useRef<HTMLDivElement>(null);

  const now = new Date();
  const slotWidth = 150;
  const channelColumnWidth = 180;

  const gridStart = useMemo(() => {
    const date = new Date(selectedDate);
    date.setHours(date.getHours() - 1, 0, 0, 0);
    return date;
  }, [selectedDate]);

  const timeSlots = useMemo(() => {
    const slots: Date[] = [];
    const current = new Date(gridStart);
    for (let i = 0; i < 12; i++) {
      slots.push(new Date(current));
      current.setMinutes(current.getMinutes() + 30);
    }
    return slots;
  }, [gridStart]);

  const filteredChannels = useMemo(() => {
    if (!searchQuery) return channels;
    const query = searchQuery.toLowerCase();
    return channels.filter((c) => c.name.toLowerCase().includes(query));
  }, [channels, searchQuery]);

  const programsByChannel = useMemo(() => {
    const map = new Map<string, EpgProgram[]>();
    programs.forEach((program) => {
      const existing = map.get(program.channelId) || [];
      existing.push(program);
      map.set(program.channelId, existing);
    });
    return map;
  }, [programs]);

  const navigateTime = (direction: number) => {
    const newDate = new Date(selectedDate);
    newDate.setHours(newDate.getHours() + direction * 2);
    setSelectedDate(newDate);
  };

  const goToNow = () => {
    setSelectedDate(new Date());
  };

  const currentTimeOffset = useMemo(() => {
    const offsetMinutes = (now.getTime() - gridStart.getTime()) / (1000 * 60);
    return (offsetMinutes / 30) * slotWidth;
  }, [now, gridStart, slotWidth]);

  if (channels.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
        <Clock className="w-12 h-12 mb-4 opacity-30" />
        <p className="text-lg font-medium">No EPG data available</p>
        <p className="text-sm mt-1">Program guide will appear when available</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search programs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-epg"
          />
        </div>

        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="outline"
            onClick={() => navigateTime(-1)}
            data-testid="button-epg-prev"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            onClick={goToNow}
            className="gap-2"
            data-testid="button-epg-now"
          >
            <Radio className="w-4 h-4" />
            Now
          </Button>
          <Button
            size="icon"
            variant="outline"
            onClick={() => navigateTime(1)}
            data-testid="button-epg-next"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        <p className="text-sm text-muted-foreground">
          {selectedDate.toLocaleDateString([], {
            weekday: "short",
            month: "short",
            day: "numeric",
          })}
        </p>
      </div>

      <div className="flex-1 overflow-hidden rounded-md border bg-card">
        <div className="flex">
          <div
            className="sticky left-0 z-20 bg-card border-r"
            style={{ width: channelColumnWidth }}
          >
            <div className="h-10 border-b bg-muted/50 flex items-center px-3">
              <span className="text-sm font-medium text-muted-foreground">
                Channels
              </span>
            </div>
          </div>

          <ScrollArea className="flex-1" ref={scrollRef}>
            <div className="relative">
              <div
                className="sticky top-0 z-10 flex h-10 border-b bg-muted/50"
                style={{ width: timeSlots.length * slotWidth }}
              >
                {timeSlots.map((slot, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-center border-r text-xs text-muted-foreground"
                    style={{ width: slotWidth }}
                  >
                    {formatTime(slot)}
                  </div>
                ))}
              </div>

              {currentTimeOffset > 0 &&
                currentTimeOffset < timeSlots.length * slotWidth && (
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-destructive z-30"
                    style={{ left: currentTimeOffset }}
                  />
                )}
            </div>
          </ScrollArea>
        </div>

        <ScrollArea className="flex-1">
          <div className="flex">
            <div
              className="sticky left-0 z-20 bg-card border-r"
              style={{ width: channelColumnWidth }}
            >
              {filteredChannels.map((channel) => (
                <div
                  key={channel.id}
                  className={`flex items-center gap-2 h-14 px-3 border-b cursor-pointer hover-elevate ${
                    channel.id === currentChannelId
                      ? "bg-primary/10"
                      : ""
                  }`}
                  onClick={() => onPlayChannel(channel)}
                  data-testid={`epg-channel-${channel.id}`}
                >
                  <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                    {channel.logo ? (
                      <img
                        src={channel.logo}
                        alt={channel.name}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <span className="text-xs font-bold text-muted-foreground">
                        {channel.name.charAt(0)}
                      </span>
                    )}
                  </div>
                  <span className="text-sm font-medium truncate">
                    {channel.name}
                  </span>
                </div>
              ))}
            </div>

            <div style={{ width: timeSlots.length * slotWidth }}>
              {filteredChannels.map((channel) => {
                const channelPrograms =
                  programsByChannel.get(channel.tvgId || channel.id) || [];

                return (
                  <div
                    key={channel.id}
                    className={`relative h-14 border-b ${
                      channel.id === currentChannelId ? "bg-primary/5" : ""
                    }`}
                  >
                    {channelPrograms.map((program) => {
                      const offset = getProgramOffset(
                        program,
                        gridStart,
                        slotWidth
                      );
                      const width = getProgramWidth(program, slotWidth);
                      const isCurrent = isCurrentProgram(program, now);

                      if (offset < 0 || offset > timeSlots.length * slotWidth)
                        return null;

                      return (
                        <div
                          key={program.id}
                          className={`absolute top-1 bottom-1 rounded-md px-2 py-1 cursor-pointer overflow-hidden hover-elevate ${
                            isCurrent
                              ? "bg-primary/20 border border-primary"
                              : "bg-muted"
                          }`}
                          style={{
                            left: Math.max(0, offset),
                            width: Math.min(
                              width,
                              timeSlots.length * slotWidth - offset
                            ),
                          }}
                          onClick={() => onSelectProgram(program, channel)}
                          data-testid={`epg-program-${program.id}`}
                        >
                          <p className="text-xs font-medium truncate">
                            {program.title}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {formatTime(parseTime(program.startTime))} -{" "}
                            {formatTime(parseTime(program.endTime))}
                          </p>
                          {isCurrent && (
                            <Badge
                              variant="default"
                              className="absolute top-1 right-1 text-[10px] px-1 py-0"
                            >
                              LIVE
                            </Badge>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
