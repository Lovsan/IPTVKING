import { useState, useRef, useEffect } from "react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Settings,
  X,
  Tv,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import type { Channel, PlayerState } from "@shared/schema";

interface VideoPlayerProps {
  playerState: PlayerState;
  onClose?: () => void;
  onTogglePlay: () => void;
  onVolumeChange: (volume: number) => void;
  onToggleMute: () => void;
  onSetActive: () => void;
  showControls?: boolean;
  compact?: boolean;
}

export function VideoPlayer({
  playerState,
  onClose,
  onTogglePlay,
  onVolumeChange,
  onToggleMute,
  onSetActive,
  showControls = true,
  compact = false,
}: VideoPlayerProps) {
  const [controlsVisible, setControlsVisible] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();

  const hideControlsTimeout = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    setControlsVisible(true);
    timeoutRef.current = setTimeout(() => {
      if (playerState.isPlaying) {
        setControlsVisible(false);
      }
    }, 3000);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className={`relative bg-black rounded-md overflow-hidden ${
        playerState.isActive ? "ring-2 ring-primary" : ""
      }`}
      onMouseMove={hideControlsTimeout}
      onMouseEnter={() => setControlsVisible(true)}
      onClick={onSetActive}
      data-testid={`video-player-${playerState.id}`}
    >
      <div className="aspect-video w-full bg-gradient-to-br from-muted/20 to-muted/5 flex items-center justify-center">
        {playerState.channel ? (
          <div className="w-full h-full relative">
            {playerState.channel.logo ? (
              <img
                src={playerState.channel.logo}
                alt={playerState.channel.name}
                className="absolute inset-0 w-full h-full object-contain p-8 opacity-20"
              />
            ) : null}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white/70">
              <Tv className="w-16 h-16 mb-4 opacity-50" />
              <p className="text-lg font-medium">{playerState.channel.name}</p>
              <p className="text-sm text-white/50 mt-1">
                {playerState.isPlaying ? "Playing..." : "Paused"}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center text-muted-foreground">
            <Tv className="w-16 h-16 mb-4 opacity-30" />
            <p className="text-sm">Select a channel to play</p>
          </div>
        )}
      </div>

      {showControls && controlsVisible && playerState.channel && (
        <>
          <div className="absolute top-0 left-0 right-0 p-3 bg-gradient-to-b from-black/80 to-transparent">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <Badge variant="secondary" className="bg-black/50 text-white">
                  LIVE
                </Badge>
                <span className="text-white font-medium text-sm truncate">
                  {playerState.channel.name}
                </span>
              </div>
              {onClose && !compact && (
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                  }}
                  data-testid={`button-close-player-${playerState.id}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
            <div className="flex items-center gap-2">
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/20"
                onClick={(e) => {
                  e.stopPropagation();
                  onTogglePlay();
                }}
                data-testid={`button-toggle-play-${playerState.id}`}
              >
                {playerState.isPlaying ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5 fill-current" />
                )}
              </Button>

              <div className="flex items-center gap-2 flex-1 max-w-[120px]">
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleMute();
                  }}
                  data-testid={`button-toggle-mute-${playerState.id}`}
                >
                  {playerState.isMuted || playerState.volume === 0 ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </Button>
                {!compact && (
                  <Slider
                    value={[playerState.isMuted ? 0 : playerState.volume]}
                    max={100}
                    step={1}
                    className="w-20"
                    onValueChange={(value) => onVolumeChange(value[0])}
                    data-testid={`slider-volume-${playerState.id}`}
                  />
                )}
              </div>

              <div className="flex-1" />

              {!compact && (
                <>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-white hover:bg-white/20"
                    data-testid={`button-settings-${playerState.id}`}
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-white hover:bg-white/20"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFullscreen();
                    }}
                    data-testid={`button-fullscreen-${playerState.id}`}
                  >
                    {isFullscreen ? (
                      <Minimize className="w-4 h-4" />
                    ) : (
                      <Maximize className="w-4 h-4" />
                    )}
                  </Button>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
