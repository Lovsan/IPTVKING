import { useState } from "react";
import {
  Clock,
  Calendar,
  Trash2,
  Play,
  CheckCircle,
  AlertCircle,
  Loader2,
  Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Recording, Channel } from "@shared/schema";

interface RecordingSchedulerProps {
  recordings: Recording[];
  channels: Channel[];
  onScheduleRecording: (recording: Omit<Recording, "id" | "filePath">) => void;
  onDeleteRecording: (recordingId: string) => void;
}

function getStatusIcon(status: string) {
  switch (status) {
    case "scheduled":
      return <Clock className="w-4 h-4 text-blue-500" />;
    case "in_progress":
      return <Loader2 className="w-4 h-4 text-yellow-500 animate-spin" />;
    case "completed":
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    case "failed":
      return <AlertCircle className="w-4 h-4 text-red-500" />;
    default:
      return <Clock className="w-4 h-4" />;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case "scheduled":
      return <Badge variant="secondary">Scheduled</Badge>;
    case "in_progress":
      return <Badge className="bg-yellow-500/20 text-yellow-500">Recording</Badge>;
    case "completed":
      return <Badge className="bg-green-500/20 text-green-500">Completed</Badge>;
    case "failed":
      return <Badge variant="destructive">Failed</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function formatDateTime(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function calculateDuration(start: string, end: string): string {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const minutes = Math.floor((endDate.getTime() - startDate.getTime()) / 60000);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours}h ${remainingMinutes}m`;
}

export function RecordingScheduler({
  recordings,
  channels,
  onScheduleRecording,
  onDeleteRecording,
}: RecordingSchedulerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<string>("");
  const [programTitle, setProgramTitle] = useState("");
  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState("60");

  const handleSchedule = () => {
    if (!selectedChannel || !programTitle || !startDate || !startTime) return;

    const startDateTime = new Date(`${startDate}T${startTime}`);
    const endDateTime = new Date(
      startDateTime.getTime() + parseInt(duration) * 60000
    );

    onScheduleRecording({
      channelId: selectedChannel,
      programTitle,
      scheduledStart: startDateTime.toISOString(),
      scheduledEnd: endDateTime.toISOString(),
      status: "scheduled",
    });

    setSelectedChannel("");
    setProgramTitle("");
    setStartDate("");
    setStartTime("");
    setDuration("60");
    setIsOpen(false);
  };

  const scheduledRecordings = recordings.filter((r) => r.status === "scheduled");
  const inProgressRecordings = recordings.filter(
    (r) => r.status === "in_progress"
  );
  const completedRecordings = recordings.filter(
    (r) => r.status === "completed" || r.status === "failed"
  );

  const getChannelName = (channelId: string) => {
    return channels.find((c) => c.id === channelId)?.name || "Unknown Channel";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Recordings</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-schedule-recording">
              <Plus className="w-4 h-4 mr-2" />
              Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Schedule Recording</DialogTitle>
            </DialogHeader>

            <div className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Channel
                </label>
                <Select
                  value={selectedChannel}
                  onValueChange={setSelectedChannel}
                >
                  <SelectTrigger data-testid="select-recording-channel">
                    <SelectValue placeholder="Select a channel" />
                  </SelectTrigger>
                  <SelectContent>
                    {channels.map((channel) => (
                      <SelectItem key={channel.id} value={channel.id}>
                        {channel.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Program Title
                </label>
                <Input
                  placeholder="Enter program name"
                  value={programTitle}
                  onChange={(e) => setProgramTitle(e.target.value)}
                  data-testid="input-program-title"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Date</label>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    data-testid="input-recording-date"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Time</label>
                  <Input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    data-testid="input-recording-time"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Duration
                </label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger data-testid="select-recording-duration">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                    <SelectItem value="180">3 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                className="w-full"
                onClick={handleSchedule}
                disabled={
                  !selectedChannel || !programTitle || !startDate || !startTime
                }
                data-testid="button-confirm-schedule"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Recording
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {recordings.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <Calendar className="w-10 h-10 mb-3 opacity-30" />
            <p className="text-sm">No recordings scheduled</p>
            <p className="text-xs mt-1">Schedule a recording to get started</p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-[400px]">
          <div className="space-y-4">
            {inProgressRecordings.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">
                  In Progress
                </h3>
                <div className="space-y-2">
                  {inProgressRecordings.map((recording) => (
                    <Card
                      key={recording.id}
                      className="border-yellow-500/30"
                      data-testid={`card-recording-${recording.id}`}
                    >
                      <CardContent className="flex items-center gap-3 p-3">
                        {getStatusIcon(recording.status || "scheduled")}
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">
                            {recording.programTitle}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {getChannelName(recording.channelId)}
                          </p>
                        </div>
                        {getStatusBadge(recording.status || "scheduled")}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {scheduledRecordings.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">
                  Scheduled
                </h3>
                <div className="space-y-2">
                  {scheduledRecordings.map((recording) => (
                    <Card
                      key={recording.id}
                      data-testid={`card-recording-${recording.id}`}
                    >
                      <CardContent className="flex items-center gap-3 p-3">
                        {getStatusIcon(recording.status || "scheduled")}
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">
                            {recording.programTitle}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {getChannelName(recording.channelId)} •{" "}
                            {formatDateTime(recording.scheduledStart)} •{" "}
                            {calculateDuration(
                              recording.scheduledStart,
                              recording.scheduledEnd
                            )}
                          </p>
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => onDeleteRecording(recording.id)}
                          data-testid={`button-delete-recording-${recording.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {completedRecordings.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">
                  Completed
                </h3>
                <div className="space-y-2">
                  {completedRecordings.map((recording) => (
                    <Card
                      key={recording.id}
                      data-testid={`card-recording-${recording.id}`}
                    >
                      <CardContent className="flex items-center gap-3 p-3">
                        {getStatusIcon(recording.status || "scheduled")}
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">
                            {recording.programTitle}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {getChannelName(recording.channelId)} •{" "}
                            {formatDateTime(recording.scheduledStart)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(recording.status || "scheduled")}
                          {recording.status === "completed" && (
                            <Button
                              size="icon"
                              variant="ghost"
                              data-testid={`button-play-recording-${recording.id}`}
                            >
                              <Play className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => onDeleteRecording(recording.id)}
                            data-testid={`button-delete-recording-${recording.id}`}
                          >
                            <Trash2 className="w-4 h-4 text-muted-foreground" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
