import { useState } from "react";
import { Grid2X2, Grid3X3, Maximize2, Link, Unlink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { VideoPlayer } from "./video-player";
import type { Channel, PlayerState } from "@shared/schema";

interface MultiViewPlayerProps {
  players: PlayerState[];
  onPlayChannel: (playerId: number, channel: Channel) => void;
  onTogglePlay: (playerId: number) => void;
  onVolumeChange: (playerId: number, volume: number) => void;
  onToggleMute: (playerId: number) => void;
  onSetActivePlayer: (playerId: number) => void;
  onClosePlayer: (playerId: number) => void;
}

type ViewMode = 1 | 2 | 4;

export function MultiViewPlayer({
  players,
  onTogglePlay,
  onVolumeChange,
  onToggleMute,
  onSetActivePlayer,
  onClosePlayer,
}: MultiViewPlayerProps) {
  const [viewMode, setViewMode] = useState<ViewMode>(1);
  const [isSynced, setIsSynced] = useState(false);

  const activePlayersCount = players.filter((p) => p.channel !== null).length;
  const visiblePlayers = players.slice(0, viewMode);

  const getGridClass = () => {
    switch (viewMode) {
      case 1:
        return "grid-cols-1";
      case 2:
        return "grid-cols-1 md:grid-cols-2";
      case 4:
        return "grid-cols-1 md:grid-cols-2";
      default:
        return "grid-cols-1";
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between gap-4 mb-4">
        <h2 className="text-lg font-semibold">Player</h2>
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant={isSynced ? "default" : "outline"}
            onClick={() => setIsSynced(!isSynced)}
            title={isSynced ? "Unsync players" : "Sync players"}
            data-testid="button-toggle-sync"
          >
            {isSynced ? (
              <Link className="w-4 h-4" />
            ) : (
              <Unlink className="w-4 h-4" />
            )}
          </Button>
          <div className="flex items-center border rounded-md">
            <Button
              size="icon"
              variant={viewMode === 1 ? "secondary" : "ghost"}
              onClick={() => setViewMode(1)}
              className="rounded-r-none"
              data-testid="button-view-1"
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant={viewMode === 2 ? "secondary" : "ghost"}
              onClick={() => setViewMode(2)}
              className="rounded-none border-x"
              data-testid="button-view-2"
            >
              <Grid2X2 className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant={viewMode === 4 ? "secondary" : "ghost"}
              onClick={() => setViewMode(4)}
              className="rounded-l-none"
              data-testid="button-view-4"
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className={`grid ${getGridClass()} gap-4`}>
        {visiblePlayers.map((player) => (
          <VideoPlayer
            key={player.id}
            playerState={player}
            onClose={() => onClosePlayer(player.id)}
            onTogglePlay={() => onTogglePlay(player.id)}
            onVolumeChange={(vol) => onVolumeChange(player.id, vol)}
            onToggleMute={() => onToggleMute(player.id)}
            onSetActive={() => onSetActivePlayer(player.id)}
            compact={viewMode === 4}
          />
        ))}
      </div>

      {activePlayersCount > 0 && (
        <p className="text-xs text-muted-foreground mt-3 text-center">
          {activePlayersCount} active stream{activePlayersCount > 1 ? "s" : ""}
          {isSynced && " (synced)"}
        </p>
      )}
    </Card>
  );
}
