import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const playlists = pgTable("playlists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  url: text("url"),
  filePath: text("file_path"),
  channelCount: integer("channel_count").default(0),
  isActive: boolean("is_active").default(true),
});

export const insertPlaylistSchema = createInsertSchema(playlists).omit({ id: true });
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type Playlist = typeof playlists.$inferSelect;

export const channels = pgTable("channels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playlistId: varchar("playlist_id").notNull(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  logo: text("logo"),
  group: text("group"),
  tvgId: text("tvg_id"),
  tvgName: text("tvg_name"),
  isFavorite: boolean("is_favorite").default(false),
});

export const insertChannelSchema = createInsertSchema(channels).omit({ id: true });
export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type Channel = typeof channels.$inferSelect;

export const favorites = pgTable("favorites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  channelId: varchar("channel_id").notNull(),
  order: integer("order").default(0),
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({ id: true });
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;

export const epgPrograms = pgTable("epg_programs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  channelId: text("channel_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  category: text("category"),
});

export const insertEpgProgramSchema = createInsertSchema(epgPrograms).omit({ id: true });
export type InsertEpgProgram = z.infer<typeof insertEpgProgramSchema>;
export type EpgProgram = typeof epgPrograms.$inferSelect;

export const recordings = pgTable("recordings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  channelId: varchar("channel_id").notNull(),
  programTitle: text("program_title").notNull(),
  scheduledStart: text("scheduled_start").notNull(),
  scheduledEnd: text("scheduled_end").notNull(),
  status: text("status").default("scheduled"),
  filePath: text("file_path"),
});

export const insertRecordingSchema = createInsertSchema(recordings).omit({ id: true });
export type InsertRecording = z.infer<typeof insertRecordingSchema>;
export type Recording = typeof recordings.$inferSelect;

export interface SystemStats {
  cpu: number;
  memory: number;
  bitrate: number;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: string;
}

export interface SyncEvent {
  type: 'play' | 'pause' | 'seek' | 'channel_change';
  channelId?: string;
  position?: number;
  timestamp: string;
}

export interface PlayerState {
  id: number;
  channelId: string | null;
  channel: Channel | null;
  isPlaying: boolean;
  volume: number;
  isMuted: boolean;
  isActive: boolean;
}
